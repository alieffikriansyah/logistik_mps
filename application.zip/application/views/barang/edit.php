<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Edit Barang
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('barang') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Kembali
                            </span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open_multipart('', [], ['stok' => 0, 'id_barang' => $barang['id_barang']]); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="nama_barang">Nama Barang</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('nama_barang', $barang['nama_barang']); ?>" name="nama_barang" id="nama_barang" type="text" class="form-control" placeholder="Nama Barang...">
                        <?= form_error('nama_barang', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="jenis_id">Jenis Barang</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <select name="jenis_id" id="jenis_id" class="custom-select">
                                <option value="" selected disabled>Pilih Jenis Barang</option>
                                <?php foreach ($jenis as $j) : ?>
                                    <option <?= $barang['jenis_id'] == $j['id_jenis'] ? 'selected' : ''; ?> <?= set_select('jenis_id', $j['id_jenis']) ?> value="<?= $j['id_jenis'] ?>"><?= $j['nama_jenis'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('jenis/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('jenis_id', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="satuan_id">Satuan Barang</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <select name="satuan_id" id="satuan_id" class="custom-select">
                                <option value="" selected disabled>Pilih Satuan Barang</option>
                                <?php foreach ($satuan as $s) : ?>
                                    <option <?= $barang['satuan_id'] == $s['id_satuan'] ? 'selected' : ''; ?> <?= set_select('satuan_id', $s['id_satuan']) ?> value="<?= $s['id_satuan'] ?>"><?= $s['nama_satuan'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('satuan/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('satuan_id', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                 <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="merk">merk</label>
                    <div class="col-md-5">
                        <input id="merk" type="text" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="foto_barang">Foto Barang</label>
                    <div class="col-md-9">
                        <!-- Preview foto saat ini -->
                        <?php if (!empty($barang['foto_barang']) && file_exists(FCPATH . 'assets/uploads/fotobarang/' . $barang['foto_barang'])) : ?>
                            <div class="mb-3">
                                <p class="mb-1">Foto Saat Ini:</p>
                                <img src="<?= base_url('assets/uploads/fotobarang/' . $barang['foto_barang']); ?>" 
                                    alt="Foto Barang" 
                                    class="img-thumbnail" 
                                    style="width: 150px; height: 150px; object-fit: cover;">
                                <div class="mt-1">
                                    <small class="text-muted"><?= $barang['foto_barang']; ?></small>
                                </div>
                            </div>
                        <?php else : ?>
                            <div class="mb-3">
                                <span class="badge badge-secondary">Tidak ada foto</span>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Input upload foto baru -->
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="foto_barang" name="foto_barang" accept="image/*">
                            <label class="custom-file-label" for="foto_barang" id="foto_barang_label">Pilih file foto baru...</label>
                        </div>
                        <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah foto. Format: JPG, JPEG, PNG, GIF (Maksimal 2MB)</small>
                        <?= form_error('foto_barang', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-md-9 offset-md-3">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                        <a href="<?= base_url('barang'); ?>" class="btn btn-light">Kembali</a>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>

        </div>
    </div>
</div>


<script>
// Untuk menampilkan nama file di custom file input
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('foto_barang');
    const fileLabel = document.getElementById('foto_barang_label');
    
    fileInput.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            fileLabel.innerText = this.files[0].name;
        } else {
            fileLabel.innerText = 'Pilih file foto baru...';
        }
    });
    
    // Reset form handler
    document.querySelector('button[type="reset"]').addEventListener('click', function() {
        setTimeout(function() {
            fileLabel.innerText = 'Pilih file foto baru...';
        }, 0);
    });
});
</script>